console.log("Starting Node server...");
const express = require('express');
const app = express();
const PORT = 3000;

// Middleware to parse JSON
app.use(express.json());

// API routes under /api/v1
const router = express.Router();

// GET /api/v1/users
router.get('/users', (req, res) => {
  res.json([
    { id: 1, name: 'Alice' },
    { id: 2, name: 'Bob' }
  ]);
});

// POST /api/v1/users
router.post('/users', (req, res) => {
  const user = req.body;
  user.id = Math.floor(Math.random() * 1000);
  res.status(201).json(user);
});

// Attach the router
app.use('/api/v1', router);

// Start the server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}/api/v1`);
});
