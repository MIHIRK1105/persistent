function fn() {
  var config = {};

  
  config.baseUrl = 'http://localhost:3000/api/v1';

  
  config.testData = read('classpath:tests/TEST_DATA.json');

  config.headers = { 'Content-Type': 'application/json' };

  return config;
}
