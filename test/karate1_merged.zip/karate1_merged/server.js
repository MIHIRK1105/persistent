// server.js

const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const app = express();
app.use(express.json());

// === DATABASE SETUP ===
const db = new sqlite3.Database('./employees.db', (err) => {
  if (err) {
    console.error("Error opening database:", err.message);
  } else {
    console.log("✅ Connected to SQLite database.");
  }
});

// Create employees table if it doesn’t exist
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS employees (
    employeeId TEXT PRIMARY KEY,
    employeeName TEXT,
    managerEmail TEXT,
    enrollmentStatus TEXT,
    enrolledSpecializationName TEXT,
    expectedCompetency TEXT,
    daysToGo INTEGER,
    endDate TEXT
  )`);

  // Insert dummy data if empty
  db.get("SELECT COUNT(*) AS count FROM employees", (err, row) => {
    if (err) return console.error(err.message);
    if (row.count === 0) {
      db.run(`INSERT INTO employees 
        (employeeId, employeeName, managerEmail, enrollmentStatus, enrolledSpecializationName, expectedCompetency, daysToGo, endDate)
        VALUES 
        ('E001', 'Alice', 'alice.manager@example.com', 'Active', 'Leadership', 'Expert', 30, '2025-11-30'),
        ('E002', 'Bob', 'bob.manager@example.com', 'Inactive', 'Communication', 'Intermediate', 60, '2025-12-31')
      `);
      console.log("Inserted initial dummy employees.");
    }
  });
});

// === ROUTES ===

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'UP', message: 'Server is healthy 🚀' });
});

// Employees endpoint (real DB data)
app.get('/employees', (req, res) => {
  db.all("SELECT * FROM employees", [], (err, rows) => {
    if (err) {
      console.error(err.message);
      return res.status(500).json({ error: err.message });
    }
    res.json(rows);
  });
});

// === FIX: Karate expects this route ===
app.get('/api/v1/users', (req, res) => {
  // Static response for Karate test
  res.json([
    { id: 1, name: 'Alice' },
    { id: 2, name: 'Bob' }
  ]);
});

// === START SERVER ===
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
