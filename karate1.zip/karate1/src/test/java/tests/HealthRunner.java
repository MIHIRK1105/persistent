package tests;

import com.intuit.karate.junit5.Karate;

class HealthRunner {

    @Karate.Test
    Karate testHealth() {
        // This will run health.feature located in the same folder
        return Karate.run("health").relativeTo(getClass());
    }
}
