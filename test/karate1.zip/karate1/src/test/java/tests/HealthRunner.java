package tests;

import com.intuit.karate.junit5.Karate;

class HealthRunner {

    @Karate.Test
    Karate testHealth() {
        return Karate.run("health").relativeTo(getClass());
    }
}
