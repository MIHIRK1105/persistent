// server.js
// --------------------------------------------
// Complete Express backend for Karate API testing
// Supports GET, POST, PUT, DELETE
// --------------------------------------------

const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// --------------------------------------------
// Health Check Endpoint
// --------------------------------------------
app.get('/api/v1/health', (req, res) => {
  res.json({ status: 'UP', message: 'Server is healthy' });
});

// --------------------------------------------
// In-memory Users Data
// --------------------------------------------
let users = [
  { id: 1, name: 'Alice' },
  { id: 2, name: 'Bob' },
];

// --------------------------------------------
// Users CRUD Routes
// --------------------------------------------

// GET all users
app.get('/api/v1/users', (req, res) => {
  res.json(users);
});

// GET user by ID
app.get('/api/v1/users/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const user = users.find((u) => u.id === id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(user);
});

// POST create user
app.post('/api/v1/users', (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: 'Name is required' });
  const id = users.length ? Math.max(...users.map((u) => u.id)) + 1 : 1;
  const newUser = { id, name };
  users.push(newUser);
  res.status(201).json(newUser);
});

// PUT update user
app.put('/api/v1/users/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const { name } = req.body;
  const idx = users.findIndex((u) => u.id === id);
  if (idx === -1) return res.status(404).json({ error: 'User not found' });
  if (!name) return res.status(400).json({ error: 'Name is required' });
  users[idx].name = name;
  res.json(users[idx]);
});

// DELETE user
app.delete('/api/v1/users/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const idx = users.findIndex((u) => u.id === id);
  if (idx === -1) return res.status(404).json({ error: 'User not found' });
  const removed = users.splice(idx, 1)[0];
  res.json(removed);
});

// --------------------------------------------
// Start Server
// --------------------------------------------
app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
});
