function fn() {
  var config = {};
  config.baseUrl = 'http://backend:3000/api/v1'; 
  return config;
}
