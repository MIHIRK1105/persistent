// -------------------- server.js --------------------
const express = require("express");
const multer = require("multer");
const app = express();
const port = 3000;

// Middleware
app.use(express.json());
const upload = multer({ dest: "uploads/" });

// --- HEALTH CHECK ---
app.get("/api/v1/health", (req, res) => {
  res.status(200).json({ status: "UP", message: "Server is healthy" });
});

// --- USERS LIST ---
app.get("/api/v1/users", (req, res) => {
  res.status(200).json([]);
});

// --- AUTH LOGIN ---
app.post("/api/v1/auth/login", (req, res) => {
  const { username, password } = req.body;

  if (username === "developer@company.com" && password === "SecurePassword123!") {
    return res.status(200).json({
      success: true,
      data: { user: { username, role: "developer" } },
    });
  }

  return res.status(401).json({
    success: false,
    error: { code: "INVALID_CREDENTIALS", message: "Invalid username or password" },
  });
});

// --- PROJECT UPLOAD ---
app.post("/api/v1/projects/upload", upload.single("project_file"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({
      success: false,
      error: { code: "INVALID_PROJECT_FILE", message: "No file uploaded" },
    });
  }

  return res.status(201).json({
    success: true,
    data: { project_name: "my-java-app", file: req.file.originalname },
  });
});

// --- ANALYSIS START ---
app.post("/api/v1/analysis/start", (req, res) => {
  const { project_id, analysis_type } = req.body;
  res.status(202).json({
    success: true,
    data: { project_id, status: "started", analysis_type },
  });
});

// --- ANALYSIS PROGRESS ---
app.get("/api/v1/analysis/:id/progress", (req, res) => {
  res.status(200).json({
    success: true,
    data: {
      status: "in_progress",
      progress: { percentage: 45 },
    },
  });
});

// --- MIGRATION EXECUTE ---
app.post("/api/v1/migration/execute", (req, res) => {
  const { plan_id } = req.body;
  if (plan_id === "plan_conflict_example") {
    return res.status(422).json({
      success: false,
      error: { code: "DEPENDENCY_CONFLICT", message: "Migration dependency conflict" },
    });
  }
  res.status(202).json({
    success: true,
    data: { plan_id, status: "started" },
  });
});

// --- DEFAULT ROUTE ---
app.use((req, res) => {
  res.status(404).json({ error: "Endpoint not found" });
});

// --- START SERVER ---
app.listen(port, () => {
  console.log(`✅ Mock API running at http://localhost:${port}/api/v1`);
});
