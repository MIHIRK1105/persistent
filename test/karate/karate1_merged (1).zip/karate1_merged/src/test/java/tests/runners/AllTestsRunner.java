package tests.runners;

import com.intuit.karate.junit5.Karate;

class AllTestsRunner {

    @Karate.Test
    Karate runAll() {
        return Karate.run(
                "classpath:tests/auth.feature",
                "classpath:tests/projects.feature",
                "classpath:tests/analysis.feature",
                "classpath:tests/migration.feature");
    }
}
