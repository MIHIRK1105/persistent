// mock-health.js
const express = require('express');
const app = express();

// This endpoint returns { status: 'UP' }
app.get('/api/v1/health', (req, res) => {
  res.json({ status: 'UP' });
});

const port = 3000;
app.listen(port, () => console.log(`✅ Mock health server running on port ${port}`));
