// server.js

const express = require('express');
const cors = require('cors');
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// --- HEALTH CHECK ---
app.get('/api/v1/health', (req, res) => {
  res.json({ status: 'UP', message: 'Server is healthy' });
});

// --- USERS CRUD ---
let users = [
  { id: 1, name: 'Alice' },
  { id: 2, name: 'Bob' }
];

// GET all users
app.get('/api/v1/users', (req, res) => {
  res.json(users);
});

// GET user by ID
app.get('/api/v1/users/:id', (req, res) => {
  const user = users.find(u => u.id === parseInt(req.params.id));
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json(user);
});

// POST create new user
app.post('/api/v1/users', (req, res) => {
  const newUser = {
    id: users.length ? Math.max(...users.map(u => u.id)) + 1 : 1,
    name: req.body.name || 'Unnamed'
  };
  users.push(newUser);
  res.status(201).json(newUser);
});

// PUT update user
app.put('/api/v1/users/:id', (req, res) => {
  const user = users.find(u => u.id === parseInt(req.params.id));
  if (!user) return res.status(404).json({ message: 'User not found' });
  user.name = req.body.name || user.name;
  res.json(user);
});

// DELETE user
app.delete('/api/v1/users/:id', (req, res) => {
  const index = users.findIndex(u => u.id === parseInt(req.params.id));
  if (index === -1) return res.status(404).json({ message: 'User not found' });
  const deletedUser = users.splice(index, 1);
  res.json(deletedUser[0]);
});

// --- EMPLOYEES SAMPLE ROUTE (OPTIONAL) ---
app.get('/api/v1/employees', (req, res) => {
  res.json([
    { id: 1, name: 'John Doe', department: 'Engineering' },
    { id: 2, name: 'Jane Smith', department: 'HR' }
  ]);
});

// --- START SERVER ---
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
});
