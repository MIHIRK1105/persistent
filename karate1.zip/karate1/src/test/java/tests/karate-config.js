function fn() {
  var config = {};
  config.baseUrl = 'http://localhost:3000/api/v1';  // your API base URL
  return config;
}
